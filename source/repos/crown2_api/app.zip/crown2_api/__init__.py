"""
Package for crown2_api.
"""
