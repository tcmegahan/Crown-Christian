"""
Definition of models.
"""


# Create your models here.
